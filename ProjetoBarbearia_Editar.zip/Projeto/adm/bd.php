<?php

$banco  = mysqli_connect('localhost','root','','BancoProjetoBarbearia');